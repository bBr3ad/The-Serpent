
SMODS.Booster {
    key = 'idiocracy_pack',
    loc_txt = {
        name = "Idiocracy Pack",
        text = {
            [1] = 'Choose 1 of 2 {C:red} The Serpent.{}'
        },
        group_name = "theserpe_boosters"
    },
    config = { extra = 2, choose = 1 },
    cost = 2,
    weight = 1.2,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "theserpe_theserpe_jokers",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "theserpe_idiocracy_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'the_plant_coping_mechanism_pack',
        loc_txt = {
            name = "The Plant Coping Mechanism Pack",
            text = {
                [1] = 'Choose 1 of 4 {C:red} The Serpent.{}',
                [2] = 'Sorry for your photochad build...'
            },
            group_name = "theserpe_boosters"
        },
        config = { extra = 4, choose = 1 },
        weight = 1.85,
        atlas = "CustomBoosters",
        pos = { x = 1, y = 0 },
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            return {
                set = "theserpe_theserpe_jokers",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "theserpe_the_plant_coping_mechanism_pack"
            }
        end,
        particles = function(self)
            -- No particles for joker packs
            end,
        }
        
        
        SMODS.Booster {
            key = 'wheel_of_packs',
            loc_txt = {
                name = "Wheel! Of! Packs!",
                text = {
                    [1] = 'Choose 2 of 7 {C:red}The Serpent.{}',
                    [2] = '{C:purple}Nope!{}'
                },
                group_name = "theserpe_boosters"
            },
            config = { extra = 7, choose = 2 },
            cost = 10,
            weight = 1.1,
            atlas = "CustomBoosters",
            pos = { x = 2, y = 0 },
            discovered = true,
            loc_vars = function(self, info_queue, card)
                local cfg = (card and card.ability) or self.config
                return {
                    vars = { cfg.choose, cfg.extra }
                }
            end,
            create_card = function(self, card, i)
                return {
                    set = "theserpe_theserpe_jokers",
                    area = G.pack_cards,
                    skip_materialize = true,
                    soulable = true,
                    key_append = "theserpe_wheel_of_packs"
                }
            end,
            particles = function(self)
                -- No particles for joker packs
                end,
            }
            
            
            SMODS.Booster {
                key = 'this_pack_is_a_green_screen',
                loc_txt = {
                    name = "This Pack Is A Green Screen",
                    text = {
                        [1] = 'Choose 1 of 9 {C:red}The Serpent.{}',
                        [2] = 'A video editor\'s dream. For this cheap?!'
                    },
                    group_name = "theserpe_boosters"
                },
                config = { extra = 9, choose = 1 },
                cost = 11,
                weight = 0.9,
                atlas = "CustomBoosters",
                pos = { x = 3, y = 0 },
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    return {
                        set = "theserpe_theserpe_jokers",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "theserpe_this_pack_is_a_green_screen"
                    }
                end,
                particles = function(self)
                    -- No particles for joker packs
                    end,
                }
                