
SMODS.Enhancement {
    key = 'trash',
    pos = { x = 0, y = 0 },
    config = {
        bonus = 30
    },
    loc_txt = {
        name = 'Trash',
        text = {
            [1] = 'Does {C:attention}nothing{} when scored',
            [2] = 'Counts as no suit or rank',
            [3] = ''
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0
}