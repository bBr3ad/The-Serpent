SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/brainrot.lua"))()
    assert(SMODS.load_file("jokers/chip.lua"))()
    assert(SMODS.load_file("jokers/pieday.lua"))()
    assert(SMODS.load_file("jokers/jimbolover.lua"))()
    assert(SMODS.load_file("jokers/freak.lua"))()
    assert(SMODS.load_file("jokers/detergent.lua"))()
    assert(SMODS.load_file("jokers/jackenstein.lua"))()
    assert(SMODS.load_file("jokers/night.lua"))()
    assert(SMODS.load_file("jokers/_3blueprintsinshop.lua"))()
    assert(SMODS.load_file("jokers/mustbeanumber.lua"))()
    assert(SMODS.load_file("jokers/kidwhodrankbatteryacid.lua"))()
    assert(SMODS.load_file("jokers/lineart.lua"))()
    assert(SMODS.load_file("jokers/babyjoker.lua"))()
    assert(SMODS.load_file("jokers/anarchist.lua"))()
    assert(SMODS.load_file("jokers/fatjoker.lua"))()
    assert(SMODS.load_file("jokers/unfinishedjoker.lua"))()
    assert(SMODS.load_file("jokers/erraticjoker.lua"))()
    assert(SMODS.load_file("jokers/mailbox.lua"))()
    assert(SMODS.load_file("jokers/kendricklamar.lua"))()
    assert(SMODS.load_file("jokers/theunseenexplosion.lua"))()
    assert(SMODS.load_file("jokers/emoji.lua"))()
    assert(SMODS.load_file("jokers/jokerbutohmygodguystheygothim.lua"))()
    assert(SMODS.load_file("jokers/capitalism.lua"))()
    assert(SMODS.load_file("jokers/bean.lua"))()
    assert(SMODS.load_file("jokers/man.lua"))()
    assert(SMODS.load_file("jokers/everythingcat.lua"))()
    assert(SMODS.load_file("jokers/thedump.lua"))()
    assert(SMODS.load_file("jokers/sacrifice.lua"))()
    assert(SMODS.load_file("jokers/speedyjoker.lua"))()
    assert(SMODS.load_file("jokers/undiscoveredjoker.lua"))()
    assert(SMODS.load_file("jokers/filejoker.lua"))()
    assert(SMODS.load_file("jokers/repeatjoker.lua"))()
    assert(SMODS.load_file("jokers/lasvegas.lua"))()
    assert(SMODS.load_file("jokers/gooutwitha.lua"))()
    assert(SMODS.load_file("jokers/kaufmo.lua"))()
    assert(SMODS.load_file("jokers/one.lua"))()
    assert(SMODS.load_file("jokers/clickbait.lua"))()
    assert(SMODS.load_file("jokers/spamtongspamton.lua"))()
end
-- load the enhancements
if true then
    assert(SMODS.load_file("enhancements/trash.lua"))()
end

-- load the decks
if true then
    assert(SMODS.load_file("decks/serpent_deck.lua"))()
end


-- load boosters
assert(SMODS.load_file("boosters.lua"))()
SMODS.ObjectType({
    key = "theserpe_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "theserpe_theserpe_jokers",
    cards = {
        ["j_theserpe_brainrot"] = true,
        ["j_theserpe_chip"] = true,
        ["j_theserpe_pieday"] = true,
        ["j_theserpe_jimbolover"] = true,
        ["j_theserpe_freak"] = true,
        ["j_theserpe_detergent"] = true,
        ["j_theserpe_jackenstein"] = true,
        ["j_theserpe_night"] = true,
        ["j_theserpe__3blueprintsinshop"] = true,
        ["j_theserpe_mustbeanumber"] = true,
        ["j_theserpe_kidwhodrankbatteryacid"] = true,
        ["j_theserpe_lineart"] = true,
        ["j_theserpe_babyjoker"] = true,
        ["j_theserpe_anarchist"] = true,
        ["j_theserpe_fatjoker"] = true,
        ["j_theserpe_unfinishedjoker"] = true,
        ["j_theserpe_erraticjoker"] = true,
        ["j_theserpe_mailbox"] = true,
        ["j_theserpe_kendricklamar"] = true,
        ["j_theserpe_theunseenexplosion"] = true,
        ["j_theserpe_emoji"] = true,
        ["j_theserpe_jokerbutohmygodguystheygothim"] = true,
        ["j_theserpe_capitalism"] = true,
        ["j_theserpe_bean"] = true,
        ["j_theserpe_man"] = true,
        ["j_theserpe_everythingcat"] = true,
        ["j_theserpe_thedump"] = true,
        ["j_theserpe_sacrifice"] = true,
        ["j_theserpe_speedyjoker"] = true,
        ["j_theserpe_undiscoveredjoker"] = true,
        ["j_theserpe_filejoker"] = true,
        ["j_theserpe_repeatjoker"] = true,
        ["j_theserpe_lasvegas"] = true,
        ["j_theserpe_gooutwitha"] = true,
        ["j_theserpe_kaufmo"] = true,
        ["j_theserpe_one"] = true,
        ["j_theserpe_clickbait"] = true,
        ["j_theserpe_spamtongspamton"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {},
        post_trigger = true 
    }
end