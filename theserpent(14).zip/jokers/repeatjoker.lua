
SMODS.Joker{ --Repeat Joker
    key = "repeatjoker",
    config = {
        extra = {
            odds = 2,
            xmult0 = 0.95,
            repetitions0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Repeat Joker',
        ['text'] = {
            [1] = 'Retriggers all {C:attention}playing cards.{}',
            [2] = 'When a playing card is triggered or retriggered,',
            [3] = 'this joker has a {C:uncommon}#1# in #2#{} chance to give {X:red,C:white}0.95X{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_theserpe_repeatjoker') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_441232ab', 1, card.ability.extra.odds, 'j_theserpe_repeatjoker', false) then
                    SMODS.calculate_effect({Xmult = 0.95}, card)
                end
            else
                return {
                    repetitions = 1,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}