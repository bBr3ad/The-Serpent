
SMODS.Joker{ --Bean
    key = "bean",
    config = {
        extra = {
            hand_size_increase = '2'
        }
    },
    loc_txt = {
        ['name'] = 'Bean',
        ['text'] = {
            [1] = '{C:attention}+2 hand size{}',
            [2] = 'Additional {C:attention}+3 hand size{} if your real life',
            [3] = 'name is Bean Balatro',
            [4] = '{C:inactive}(Currently inactive){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(2)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-2)
    end
}