
SMODS.Joker{ --Brainrot
    key = "brainrot",
    config = {
        extra = {
            xchips0 = 6.7
        }
    },
    loc_txt = {
        ['name'] = 'Brainrot',
        ['text'] = {
            [1] = '{X:red,C:white}x6.7{} if you have exactly 6 or 7 jokers'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (to_big(#G.jokers.cards) > to_big(5) and to_big(#G.jokers.cards) < to_big(8)) then
                return {
                    x_chips = 6.7
                }
            end
        end
    end
}