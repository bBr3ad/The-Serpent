
SMODS.Joker{ --Spamton G. Spamton
    key = "spamtongspamton",
    config = {
        extra = {
            Multiplication = 1,
            money÷10 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Spamton G. Spamton',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X0.1{} for every {C:money}[[Kromer]] {} you have',
            [2] = '(Currently{X:red,C:white} #1#x{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Multiplication, card.ability.extra.money÷10 + ((math.floor(lenient_bignum(G.GAME.dollars / 10)) or 0))}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.Multiplication = card.ability.extra.money÷10 + (math.floor(lenient_bignum(G.GAME.dollars / 10)))
            return {
                Xmult = card.ability.extra.Multiplication
            }
        end
    end
}