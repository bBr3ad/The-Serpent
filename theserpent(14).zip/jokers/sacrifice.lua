
SMODS.Joker{ --Sacrifice
    key = "sacrifice",
    config = {
        extra = {
            discardsremaining = 0
        }
    },
    loc_txt = {
        ['name'] = 'Sacrifice',
        ['text'] = {
            [1] = 'If the {C:red}last discard{} of a blind has only {C:attention}1 card{},',
            [2] = 'this joker creates a copy of that card and',
            [3] = 'adds it{C:attention} to the deck{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(G.GAME.current_round.discards_left or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.discard  then
            if (to_big(G.GAME.current_round.discards_left) == to_big(1) and context.other_card == context.full_hand[1] and context.other_card == context.full_hand[#context.full_hand]) then
                return {
                    
                    func = function()
                        
                        G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                        local copied_card = copy_card(context.other_card, nil, nil, G.playing_card)
                        copied_card:add_to_deck()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        table.insert(G.playing_cards, copied_card)
                        G.hand:emplace(copied_card)
                        playing_card_joker_effects({true})
                        G.E_MANAGER:add_event(Event({
                            func = function() 
                                copied_card:start_materialize()
                                return true
                            end
                        }))
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                SMODS.calculate_context({ playing_card_added = true, cards = { copied_card } })
                                return true
                            end
                        }))
                    end,
                    message = "Copied Card to Hand!"
                }
            end
        end
    end
}