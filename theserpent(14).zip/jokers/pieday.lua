
SMODS.Joker{ --Pie Day
    key = "pieday",
    config = {
        extra = {
            Money = 1
        }
    },
    loc_txt = {
        ['name'] = 'Pie Day',
        ['text'] = {
            [1] = 'Earn {C:gold}$#1#{} at end of round',
            [2] = 'Increase by {C:attention}1{} when a {C:attention}3, Ace, or 4{} is scored',
            [3] = 'Decreases by {C:attention}1{} when a face card is scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Money}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 3 then
                card.ability.extra.Money = (card.ability.extra.Money) + 1
                return {
                    message = "3!"
                }
            elseif context.other_card:get_id() == 14 then
                card.ability.extra.Money = (card.ability.extra.Money) + 1
                return {
                    message = "1!"
                }
            elseif context.other_card:get_id() == 4 then
                card.ability.extra.Money = (card.ability.extra.Money) + 1
                return {
                    message = "4!"
                }
            elseif context.other_card:is_face() then
                card.ability.extra.Money = math.max(0, (card.ability.extra.Money) - 1)
                return {
                    message = "4!"
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + card.ability.extra.Money
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.Money), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}