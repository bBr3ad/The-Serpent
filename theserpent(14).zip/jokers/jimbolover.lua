
SMODS.Joker{ --Jimbo Lover
    key = "jimbolover",
    config = {
        extra = {
            XMult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Jimbo Lover',
        ['text'] = {
            [1] = 'Gains {X:red,C:white}X0.05{} when {C:attention}ANY joker{} is triggered.',
            [2] = '{C:inactive}(Currently {X:red,C:white}X#1#{}{C:inactive}){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' 
            or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.XMult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.XMult
            }
        end
        if context.post_trigger  then
            return {
                func = function()
                    card.ability.extra.XMult = (card.ability.extra.XMult) + 0.05
                    return true
                end
            }
        end
    end
}