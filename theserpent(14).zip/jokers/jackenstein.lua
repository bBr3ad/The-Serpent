
SMODS.Joker{ --Jackenstein
    key = "jackenstein",
    config = {
        extra = {
            XMult = 4
        }
    },
    loc_txt = {
        ['name'] = 'Jackenstein',
        ['text'] = {
            [1] = '{X:mult,C:white}x#1#{} Mult',
            [2] = 'Loses {X:mult,C:white}x0.01{} when a {C:attention}card is scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.XMult}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            card.ability.extra.XMult = math.max(0, (card.ability.extra.XMult) - 0.01)
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.XMult
            }
        end
    end
}