
SMODS.Joker{ --Kid Who Drank Battery Acid
    key = "kidwhodrankbatteryacid",
    config = {
        extra = {
            handsplayedthisround = 0,
            xmult0 = 4,
            xmult = 0.25
        }
    },
    loc_txt = {
        ['name'] = 'Kid Who Drank Battery Acid',
        ['text'] = {
            [1] = '{X:mult,C:white}x4{} Mult if first hand of the round',
            [2] = '{X:mult,C:white}x0.25{} Mult if not the first hand of the round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(G.GAME.current_round.hands_played or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_played == 0 then
                return {
                    Xmult = 4
                }
            elseif to_big(2) < to_big(G.GAME.current_round.hands_played) then
                return {
                    Xmult = 0.25
                }
            end
        end
    end
}