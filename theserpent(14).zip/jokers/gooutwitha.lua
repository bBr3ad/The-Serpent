
SMODS.Joker{ --Go Out With A
    key = "gooutwitha",
    config = {
        extra = {
            Bang = 1,
            dollars0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Go Out With A',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X0.75{} for every hand played',
            [2] = 'Resets at the end of round',
            [3] = '{C:attention}-$1{} for every hand played',
            [4] = '(Currently #1#)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Bang}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            card.ability.extra.Bang = (card.ability.extra.Bang) + 0.75
            return {
                Xmult = card.ability.extra.Bang,
                extra = {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars - 1
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(1), colour = G.C.MONEY})
                        return true
                    end,
                    colour = G.C.MONEY
                }
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.Bang = 1
                    return true
                end
            }
        end
    end
}