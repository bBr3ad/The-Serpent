
SMODS.Joker{ --chip
    key = "chip",
    config = {
        extra = {
            hands0 = 1,
            discards0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'chip',
        ['text'] = {
            [1] = 'When blind is selected, gain {C:red}4 discards{}',
            [2] = 'and set {C:blue}hands to 1.{}',
            [3] = '{C:inactive}(Art by Glitchkat10){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(1).." Hands", colour = G.C.BLUE})
                    G.GAME.current_round.hands_left = 1
                    return true
                end,
                extra = {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(4).." Discards", colour = G.C.GREEN})
                        
                        G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + 4
                        return true
                    end,
                    colour = G.C.GREEN
                }
            }
        end
    end
}