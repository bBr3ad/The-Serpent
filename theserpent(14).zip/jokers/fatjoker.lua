
SMODS.Joker{ --Fat Joker
    key = "fatjoker",
    config = {
        extra = {
            mult = 1,
            odds = 8
        }
    },
    loc_txt = {
        ['name'] = 'Fat Joker',
        ['text'] = {
            [1] = 'Gains {C:red}+6.72 Mult{} each round',
            [2] = '1 in 8 chance to eat a random joker',
            [3] = '{C:inactive}(Currently {C:red}+#1# Mult{}{C:inactive}){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_theserpe_fatjoker') 
        return {vars = {card.ability.extra.mult, new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.mult
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_4df2ff59', 1, card.ability.extra.odds, 'j_theserpe_fatjoker', false) then
                    SMODS.calculate_effect({func = function()
                        local destructable_jokers = {}
                        for i, joker in ipairs(G.jokers.cards) do
                            if joker ~= card and not SMODS.is_eternal(joker) and not joker.getting_sliced then
                                table.insert(destructable_jokers, joker)
                            end
                        end
                        local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "I was hungry..", colour = G.C.RED})
                        end
                        return true
                    end}, card)
                end
            else
                return {
                    func = function()
                        card.ability.extra.mult = (card.ability.extra.mult) + 6.72
                        return true
                    end
                }
            end
        end
    end
}