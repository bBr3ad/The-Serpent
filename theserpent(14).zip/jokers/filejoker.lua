
SMODS.Joker{ --File Joker
    key = "filejoker",
    config = {
        extra = {
            xmult0 = 1.25,
            xmult = 1.25,
            xmult2 = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'File Joker',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X1.25{} for each {C:attention}modificaton{} applied',
            [2] = 'to a card when the card is scored',
            [3] = '({C:enhanced}Enhancements{}, {C:dark_edition}editions{}, and {C:red}Seals{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (function()
                local enhancements = SMODS.get_enhancements(context.other_card)
                for k, v in pairs(enhancements) do
                    if v then
                        return true
                    end
                end
                return false
            end)() then
                return {
                    Xmult = 1.25
                }
            elseif context.other_card.edition ~= nil then
                return {
                    Xmult = 1.25
                }
            elseif context.other_card.seal ~= nil then
                return {
                    Xmult = 1.25
                }
            end
        end
    end
}