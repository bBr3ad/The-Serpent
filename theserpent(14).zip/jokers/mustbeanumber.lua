
SMODS.Joker{ --Must Be A Number
    key = "mustbeanumber",
    config = {
        extra = {
            mult0 = 10,
            mult = 10,
            mult2 = -10
        }
    },
    loc_txt = {
        ['name'] = 'Must Be A Number',
        ['text'] = {
            [1] = '{C:red}+10{} Mult when a number card is scored',
            [2] = '{C:red}-10{} Mult when a face card is scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) then
                return {
                    mult = 10
                }
            elseif (context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9) then
                return {
                    mult = 10
                }
            elseif context.other_card:is_face() then
                return {
                    mult = -10
                }
            end
        end
    end
}