
SMODS.Joker{ --Unfinished Joker
    key = "unfinishedjoker",
    config = {
        extra = {
            dollars0 = 1,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Unfinished Joker',
        ['text'] = {
            [1] = '{C:inactive}* Joker refuses to describe itself!{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_theserpe_unfinishedjoker') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                local created_joker = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_joker' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            
                        end
                        
                        return true
                    end
                }))
                return {
                    message = created_joker and localize('k_plus_joker') or nil,
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars - 1
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(1), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY
                    }
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_59709081', 1, card.ability.extra.odds, 'j_theserpe_unfinishedjoker', false) then
                            local available_jokers = {}
                            for i, joker in ipairs(G.jokers.cards) do
                                table.insert(available_jokers, joker)
                            end
                            local target_joker = #available_jokers > 0 and pseudorandom_element(available_jokers, pseudoseed('copy_joker')) or nil
                            
                            if target_joker and #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local copied_joker = copy_card(target_joker, nil, nil, nil, target_joker.edition and target_joker.edition.negative)
                                        
                                        copied_joker:add_to_deck()
                                        G.jokers:emplace(copied_joker)
                                        G.GAME.joker_buffer = 0
                                        return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_duplicated_ex'), colour = G.C.GREEN})
                            end
                            local available_jokers = {}
                            for i, joker in ipairs(G.jokers.cards) do
                                table.insert(available_jokers, joker)
                            end
                            local target_joker = #available_jokers > 0 and pseudorandom_element(available_jokers, pseudoseed('copy_joker')) or nil
                            
                            if target_joker and #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local copied_joker = copy_card(target_joker, nil, nil, nil, target_joker.edition and target_joker.edition.negative)
                                        
                                        copied_joker:add_to_deck()
                                        G.jokers:emplace(copied_joker)
                                        G.GAME.joker_buffer = 0
                                        return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_duplicated_ex'), colour = G.C.GREEN})
                            end
                            
                        end
                        return true
                    end
                }
            end
        end
    end
}