
SMODS.Joker{ --Capitalism
    key = "capitalism",
    config = {
        extra = {
            Xmult = 999,
            dollars0 = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'Capitalism',
        ['text'] = {
            [1] = '{X:red,C:white}X#1#{} Mult!',
            [2] = '{C:inactive}You may need to pay taxes...{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Xmult}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars / 1.2
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Taxes.", colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.setting_blind  then
            return {
                func = function()
                    card.ability.extra.Xmult = 1
                    return true
                end,
                message = "Nevermind."
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.Xmult
            }
        end
    end
}