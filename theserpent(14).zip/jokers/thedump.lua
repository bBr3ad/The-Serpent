
SMODS.Joker{ --The Dump
    key = "thedump",
    config = {
        extra = {
            xmult0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'The Dump',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X2.5{} but {C:enhanced}\"enhances\"{} the last card',
            [2] = '{C:attention}scored{} to {C:common}Trash{} on the first hand of a blind'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 2.5
            }
        end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card == context.scoring_hand[#context.scoring_hand] and G.GAME.current_round.hands_played == 0) then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_ability(G.P_CENTERS.m_theserpe_trash)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
    end
}