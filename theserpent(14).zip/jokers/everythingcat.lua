
SMODS.Joker{ --Everything Cat
    key = "everythingcat",
    config = {
        extra = {
            XMult = 1,
            enhancedcardsindeck = 1
        }
    },
    loc_txt = {
        ['name'] = 'Everything Cat',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}0.1X{} for every card in your',
            [2] = 'deck with a {C:enhanced}Enhancement{}',
            [3] = '(Currently {X:red,C:white}#1#X{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {card.ability.extra.XMult, card.ability.extra.enhancedcardsindeck + ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if next(SMODS.get_enhancements(card)) then count = count + 1 end end; return count end)()) * 0.1}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.XMult
            }
        end
        if context.setting_blind  then
            return {
                func = function()
                card.ability.extra.XMult = card.ability.extra.enhancedcardsindeck + ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if next(SMODS.get_enhancements(card)) then count = count + 1 end end; return count end)()) * 0.1
                    return true
                end
            }
        end
    end
}