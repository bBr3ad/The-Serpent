
SMODS.Joker{ --Baby Joker
    key = "babyjoker",
    config = {
        extra = {
            Chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Baby Joker',
        ['text'] = {
            [1] = 'Gains {C:common}+1 Chip{} when ANYTHING is scored.',
            [2] = '(Currently {C:common}+#1#{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Chips}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            card.ability.extra.Chips = (card.ability.extra.Chips) + 1
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            return {
                func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 1
                    return true
                end
            }
        end
        if context.other_joker  then
            return {
                func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 1
                    return true
                end
            }
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.Chips
            }
        end
    end
}