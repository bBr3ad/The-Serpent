
SMODS.Joker{ --TheUnseenExplosion
    key = "theunseenexplosion",
    config = {
        extra = {
            xMult = 1,
            cardsremovedfromdeck = 4
        }
    },
    loc_txt = {
        ['name'] = 'TheUnseenExplosion',
        ['text'] = {
            [1] = 'When a playing card is destroyed,',
            [2] = 'this joker gains {X:red,C:white}X0.25{} Mult.',
            [3] = '(Currently {X:red,C:white}X#1#{})',
            [4] = '{C:dark_edition}You could say the card.. exploded.{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xMult, card.ability.extra.cardsremovedfromdeck + (((G.GAME.starting_deck_size - #(G.playing_cards or {})) or 0)) * 0.25}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.xMult
            }
        end
        if context.remove_playing_cards  then
            return {
                func = function()
                    card.ability.extra.xMult = card.ability.extra.cardsremovedfromdeck + ((G.GAME.starting_deck_size - #(G.playing_cards or {}))) * 0.25
                    return true
                end
            }
        end
    end
}