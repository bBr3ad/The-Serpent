
SMODS.Joker{ --Speedy Joker
    key = "speedyjoker",
    config = {
        extra = {
            XMult = 1.5,
            handsplayedthisround = 0
        }
    },
    loc_txt = {
        ['name'] = 'Speedy Joker',
        ['text'] = {
            [1] = '{X:red,C:white}X#1#{} Mult',
            [2] = 'Gains {X:red,C:white}X0.75{} when you beat a blind on {C:attention}your first hand{}',
            [3] = 'Loses {X:red,C:white}X0.25{} for every hand played after the first'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.XMult, (G.GAME.current_round.hands_played or 0)}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(G.GAME.current_round.hands_played) > to_big(1) then
                card.ability.extra.XMult = math.max(0, (card.ability.extra.XMult) - 0.25)
            else
                return {
                    Xmult = card.ability.extra.XMult
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if to_big(1) == to_big(G.GAME.current_round.hands_played) then
                return {
                    func = function()
                        card.ability.extra.XMult = (card.ability.extra.XMult) + 0.75
                        return true
                    end
                }
            end
        end
    end
}