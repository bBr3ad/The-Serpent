
SMODS.Joker{ --Emoji
    key = "emoji",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Emoji',
        ['text'] = {
            [1] = '{C:red}+1{} Mult for every mile away the creator of',
            [2] = 'thismod is from your current location',
            [3] = '{C:inactive}(Currently +0 Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true }
}