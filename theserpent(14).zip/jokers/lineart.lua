
SMODS.Joker{ --Line Art
    key = "lineart",
    config = {
        extra = {
            odds = 2,
            odds2 = 4,
            odds3 = 8,
            odds4 = 16,
            odds5 = 32,
            odds6 = 64,
            odds7 = 128,
            xmult0 = 2,
            xmult = 2,
            xmult2 = 2,
            xmult3 = 2,
            xmult4 = 2,
            xmult5 = 2,
            xmult6 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Line Art',
        ['text'] = {
            [1] = '{C:uncommon}1 in 2{} chance to give {X:red,C:white}X2{}, {C:attention}recursively{}',
            [2] = '{C:inactive}(Unaffected by probabality multipliers){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_theserpe_lineart')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_theserpe_lineart')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_theserpe_lineart')
        local new_numerator4, new_denominator4 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds4, 'j_theserpe_lineart')
        local new_numerator5, new_denominator5 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds5, 'j_theserpe_lineart')
        local new_numerator6, new_denominator6 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds6, 'j_theserpe_lineart')
        local new_numerator7, new_denominator7 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds7, 'j_theserpe_lineart')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3, new_numerator4, new_denominator4, new_numerator5, new_denominator5, new_numerator6, new_denominator6, new_numerator7, new_denominator7}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_5e5a2034', 1, card.ability.extra.odds, 'j_theserpe_lineart', true) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_1_6f8c7611', 1, card.ability.extra.odds2, 'j_theserpe_lineart', true) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_2_2cca111f', 1, card.ability.extra.odds3, 'j_theserpe_lineart', true) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_3_3baef17b', 1, card.ability.extra.odds4, 'j_theserpe_lineart', true) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_4_8ec6f971', 1, card.ability.extra.odds5, 'j_theserpe_lineart', true) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_5_d3d785c9', 1, card.ability.extra.odds6, 'j_theserpe_lineart', true) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_6_622d47f5', 1, card.ability.extra.odds7, 'j_theserpe_lineart', true) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
            end
        end
    end
}