
SMODS.Joker{ --Anarchist
    key = "anarchist",
    config = {
        extra = {
            xmult0 = 1.75,
            xmult = 1.75,
            xmult2 = 1.75,
            xmult3 = 1.75,
            xmult4 = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Anarchist',
        ['text'] = {
            [1] = '{C:attention}Aces, 2s, 3s, 4s, and 5s{}',
            [2] = 'give {X:mult,C:white}x1.5{} when scored.',
            [3] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 2 then
                return {
                    Xmult = 1.75
                }
            elseif context.other_card:get_id() == 3 then
                return {
                    Xmult = 1.75
                }
            elseif context.other_card:get_id() == 4 then
                return {
                    Xmult = 1.75
                }
            elseif context.other_card:get_id() == 5 then
                return {
                    Xmult = 1.75
                }
            elseif context.other_card:get_id() == 14 then
                return {
                    Xmult = 1.75
                }
            end
        end
    end
}