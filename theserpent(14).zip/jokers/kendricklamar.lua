
SMODS.Joker{ --Kendrick Lamar
    key = "kendricklamar",
    config = {
        extra = {
            XMinor = 1
        }
    },
    loc_txt = {
        ['name'] = 'Kendrick Lamar',
        ['text'] = {
            [1] = 'Gains {X:red,C:white}x0.3{} if hand played contains a {C:attention}Ace{}',
            [2] = 'and does {C:attention}NOT{} contain an 8',
            [3] = '(Currently #1#x)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["theserpe_theserpe_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.XMinor}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:get_id() == A then
                        count = count + 1
                    end
                end
                return count >= 1
            end)()) and ((function()
                local count = 0
                for _, playing_card in pairs(context.full_hand or {}) do
                    if playing_card:get_id() == 8 then
                        count = count + 1
                    end
                end
                return count == 0
            end)()) then
                card.ability.extra.XMinor = (card.ability.extra.XMinor) + 0.3
                return {
                    message = "Dissed!"
                }
            else
                return {
                    Xmult = card.ability.extra.XMinor
                }
            end
        end
    end
}